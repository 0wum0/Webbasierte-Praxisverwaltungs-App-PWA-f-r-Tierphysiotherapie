<?php
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . "/includes/twig.php";

echo $twig->render("layout.twig", [
    "title" => "Twig-Test",
]);