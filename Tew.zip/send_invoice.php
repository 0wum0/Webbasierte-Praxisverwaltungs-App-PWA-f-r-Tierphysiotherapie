<?php
declare(strict_types=1);

require_once __DIR__ . "/includes/db.php";
require_once __DIR__ . "/includes/twig.php";
require_once __DIR__ . "/includes/mail.php";

require_once __DIR__ . "/vendor/autoload.php"; // Dompdf + PHPMailer
use Dompdf\Dompdf;
use Dompdf\Options;

// Rechnungs-ID
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die("❌ Ungültige Rechnungs-ID");
}

// Rechnung laden
$stmt = $pdo->prepare("
    SELECT i.*, p.name AS patient_name, o.firstname, o.lastname, o.email, o.street, o.zipcode, o.city
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    JOIN owners o ON p.owner_id = o.id
    WHERE i.id = :id
");
$stmt->execute([":id" => $id]);
$invoice = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$invoice) {
    die("❌ Rechnung nicht gefunden");
}
if (empty($invoice['email'])) {
    die("❌ Besitzer hat keine E-Mail-Adresse");
}

// Positionen laden
$stmt = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id = :id");
$stmt->execute([":id" => $id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// PDF erzeugen
$html = $twig->render("invoice_pdf.twig", [
    "invoice" => $invoice,
    "items" => $items,
    "today" => date("d.m.Y")
]);

$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$pdfContent = $dompdf->output();

// Mailer erstellen
$mail = createMailer($pdo);

// Mail-Texte aus Settings laden
$stmt = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('invoice_mail_subject','invoice_mail_body')");
$settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$subjectTemplate = $settings['invoice_mail_subject'] ?? "Ihre Rechnung Nr. [RECHNUNGSNUMMER]";
$bodyTemplate = $settings['invoice_mail_body'] ?? "Sehr geehrte/r [NAME],\n\nim Anhang finden Sie Ihre Rechnung Nr. [RECHNUNGSNUMMER].\n\nMit freundlichen Grüßen\nTierphysio Eileen Wenzel";

// Platzhalter ersetzen
$subject = str_replace("[RECHNUNGSNUMMER]", $invoice['id'], $subjectTemplate);
$bodyText = str_replace(
    ["[NAME]", "[RECHNUNGSNUMMER]"],
    [$invoice['firstname'] . " " . $invoice['lastname'], $invoice['id']],
    $bodyTemplate
);

// HTML-Version über globale Mail-Vorlage
$bodyHtml = $twig->render("mail_template.twig", [
    "body" => nl2br($bodyText)
]);

try {
    // Empfänger
    $mail->addAddress($invoice['email'], $invoice['firstname'] . " " . $invoice['lastname']);

    // Betreff & Nachricht
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $bodyHtml;
    $mail->AltBody = $bodyText;

    // PDF anhängen
    $mail->addStringAttachment($pdfContent, "Rechnung_" . $invoice['id'] . ".pdf");

    // Absenden
    $mail->send();

    echo "<h3>✅ Rechnung wurde erfolgreich an " . htmlspecialchars($invoice['email']) . " gesendet!</h3>";
    echo "<p><a href='invoices.php' class='btn btn-primary'>Zurück zur Übersicht</a></p>";

} catch (Exception $e) {
    echo "❌ Fehler beim Senden: {$mail->ErrorInfo}";
}