<?php
declare(strict_types=1);

require_once __DIR__ . "/includes/db.php";

// Rechnungs-ID und Zielstatus abholen
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$status = $_GET['status'] ?? '';

if ($id <= 0 || !in_array($status, ['open', 'paid'])) {
    die("❌ Ungültiger Aufruf");
}

// Status ändern
$stmt = $pdo->prepare("UPDATE invoices SET status = :status, last_updated = NOW(), sync_status = 'local' WHERE id = :id");
$stmt->execute([
    ":status" => $status,
    ":id" => $id
]);

// Erfolgsmeldung in Session speichern
session_start();
if ($status === 'paid') {
    $_SESSION['invoice_success'] = "✅ Rechnung #$id wurde als bezahlt markiert.";
} else {
    $_SESSION['invoice_success'] = "↩️ Rechnung #$id wurde wieder als offen markiert.";
}

// Zurück zur Übersicht
header("Location: invoices.php");
exit;