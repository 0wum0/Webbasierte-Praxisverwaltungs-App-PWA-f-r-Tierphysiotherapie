<?php
declare(strict_types=1);

require_once __DIR__ . "/includes/db.php";
require_once __DIR__ . "/includes/twig.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM owners WHERE id = :id");
$stmt->execute([":id" => $id]);
$owner = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$owner) {
    die("❌ Besitzer nicht gefunden");
}

$errors = [];
$success = null;

// Neue Notiz hinzufügen
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note_content'])) {
    $content = trim($_POST['note_content']);
    if ($content === '') {
        $errors[] = "Bitte eine Notiz eingeben.";
    }
    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO notes (owner_id, content, sync_status)
            VALUES (:oid, :content, 'local')
        ");
        $stmt->execute([
            ":oid" => $id,
            ":content" => $content
        ]);
        $success = "✅ Notiz gespeichert.";
    }
}

// Notiz löschen
if (isset($_GET['delete_note'])) {
    $nid = (int)$_GET['delete_note'];
    $stmt = $pdo->prepare("DELETE FROM notes WHERE id = :id AND owner_id = :oid");
    $stmt->execute([":id" => $nid, ":oid" => $id]);
    header("Location: owner.php?id=" . $id);
    exit;
}

// Notizen laden
$stmt = $pdo->prepare("SELECT * FROM notes WHERE owner_id = :oid ORDER BY created_at DESC");
$stmt->execute([":oid" => $id]);
$notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Patienten des Besitzers laden
$stmt = $pdo->prepare("SELECT * FROM patients WHERE owner_id = :oid ORDER BY name ASC");
$stmt->execute([":oid" => $id]);
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Rechnungen des Besitzers laden
$stmt = $pdo->prepare("
    SELECT i.*, p.name AS patient_name
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    WHERE p.owner_id = :oid
    ORDER BY i.id DESC
");
$stmt->execute([":oid" => $id]);
$invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Termine des Besitzers laden
$stmt = $pdo->prepare("
    SELECT a.*, p.name AS patient_name
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    WHERE p.owner_id = :oid
    ORDER BY a.appointment_date DESC
");
$stmt->execute([":oid" => $id]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Render
echo $twig->render("owner.twig", [
    "title" => "Besitzerprofil",
    "owner" => $owner,
    "patients" => $patients,
    "invoices" => $invoices,
    "appointments" => $appointments,
    "notes" => $notes,
    "errors" => $errors,
    "success" => $success
]);