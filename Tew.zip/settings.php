<?php
declare(strict_types=1);

require_once __DIR__ . "/includes/db.php";
require_once __DIR__ . "/includes/twig.php";

$errors = [];
$success = false;

// Vorhandene Einstellungen laden
$stmt = $pdo->query("SELECT * FROM settings ORDER BY setting_key ASC");
$settings = $stmt->fetchAll(PDO::FETCH_ASSOC);
$settingsMap = [];
foreach ($settings as $s) {
    $settingsMap[$s['setting_key']] = $s['setting_value'];
}

// Formular: Eigene Key/Value Settings
if (isset($_POST['setting_key']) && isset($_POST['setting_value'])) {
    $key = trim($_POST['setting_key']);
    $value = trim($_POST['setting_value']);

    if ($key === '') {
        $errors[] = "Bitte einen Schlüssel (Name) eingeben.";
    }
    if ($value === '') {
        $errors[] = "Bitte einen Wert eingeben.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = :key");
        $stmt->execute([":key" => $key]);
        $exists = (bool)$stmt->fetchColumn();

        if ($exists) {
            $stmt = $pdo->prepare("UPDATE settings SET setting_value=:value, sync_status='local' WHERE setting_key=:key");
            $stmt->execute([":value" => $value, ":key" => $key]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value, sync_status) VALUES (:key, :value, 'local')");
            $stmt->execute([":key" => $key, ":value" => $value]);
        }

        header("Location: settings.php");
        exit;
    }
}

// Formular: SMTP Einstellungen
if (isset($_POST['smtp_host'])) {
    $smtpFields = ["smtp_host", "smtp_port", "smtp_user", "smtp_pass", "smtp_from", "smtp_from_name"];

    foreach ($smtpFields as $field) {
        $value = trim($_POST[$field] ?? "");
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = :key");
        $stmt->execute([":key" => $field]);
        $exists = (bool)$stmt->fetchColumn();

        if ($exists) {
            $stmt = $pdo->prepare("UPDATE settings SET setting_value=:value, sync_status='local' WHERE setting_key=:key");
            $stmt->execute([":value" => $value, ":key" => $field]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value, sync_status) VALUES (:key, :value, 'local')");
            $stmt->execute([":key" => $field, ":value" => $value]);
        }
    }

    header("Location: settings.php");
    exit;
}

// Formular: Rechnungs-Einstellungen (Bank + Zahlungsziel + Mail)
if (isset($_POST['bank_details']) || isset($_POST['payment_terms']) || isset($_POST['invoice_mail_subject'])) {
    $invoiceFields = ["bank_details", "payment_terms", "invoice_mail_subject", "invoice_mail_body"];

    foreach ($invoiceFields as $field) {
        $value = trim($_POST[$field] ?? "");
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = :key");
        $stmt->execute([":key" => $field]);
        $exists = (bool)$stmt->fetchColumn();

        if ($exists) {
            $stmt = $pdo->prepare("UPDATE settings SET setting_value=:value, sync_status='local' WHERE setting_key=:key");
            $stmt->execute([":value" => $value, ":key" => $field]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value, sync_status) VALUES (:key, :value, 'local')");
            $stmt->execute([":key" => $field, ":value" => $value]);
        }
    }

    header("Location: settings.php");
    exit;
}

// Formular: Geburtstagsmail-Einstellungen
if (isset($_POST['birthday_mail_subject'])) {
    $birthdayFields = ["birthday_mail_subject", "birthday_mail_body"];

    foreach ($birthdayFields as $field) {
        $value = trim($_POST[$field] ?? "");
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = :key");
        $stmt->execute([":key" => $field]);
        $exists = (bool)$stmt->fetchColumn();

        if ($exists) {
            $stmt = $pdo->prepare("UPDATE settings SET setting_value=:value, sync_status='local' WHERE setting_key=:key");
            $stmt->execute([":value" => $value, ":key" => $field]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value, sync_status) VALUES (:key, :value, 'local')");
            $stmt->execute([":key" => $field, ":value" => $value]);
        }
    }

    header("Location: settings.php");
    exit;
}

// Render
echo $twig->render("settings.twig", [
    "settings" => $settings,
    "settingsMap" => $settingsMap,
    "errors" => $errors,
    "success" => $success
]);