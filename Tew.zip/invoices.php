<?php
declare(strict_types=1);

require_once __DIR__ . "/includes/db.php";
require_once __DIR__ . "/includes/twig.php";

// Rechnungen laden (offen und bezahlt getrennt)
$stmt = $pdo->prepare("
    SELECT i.*, p.name AS patient_name, o.firstname, o.lastname, o.email
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    JOIN owners o ON p.owner_id = o.id
    WHERE i.status = 'open'
    ORDER BY i.id DESC
");
$stmt->execute();
$openInvoices = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT i.*, p.name AS patient_name, o.firstname, o.lastname, o.email
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    JOIN owners o ON p.owner_id = o.id
    WHERE i.status = 'paid'
    ORDER BY i.id DESC
");
$stmt->execute();
$paidInvoices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Erfolgsmeldung aus Session (z.B. nach Versand)
session_start();
$success = $_SESSION['invoice_success'] ?? null;
unset($_SESSION['invoice_success']);

echo $twig->render("invoices.twig", [
    "title" => "Rechnungen",
    "openInvoices" => $openInvoices,
    "paidInvoices" => $paidInvoices,
    "success" => $success
]);