<?php
declare(strict_types=1);

require_once __DIR__ . "/includes/db.php";
require_once __DIR__ . "/includes/twig.php";

require_once __DIR__ . "/vendor/autoload.php";
use Dompdf\Dompdf;
use Dompdf\Options;

// Rechnungs-ID prüfen
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die("❌ Ungültige Rechnungs-ID");
}

// Rechnung laden
$stmt = $pdo->prepare("
    SELECT i.*, p.name AS patient_name, o.firstname, o.lastname, o.street, o.zipcode, o.city, o.email
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    JOIN owners o ON p.owner_id = o.id
    WHERE i.id = :id
");
$stmt->execute([":id" => $id]);
$invoice = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$invoice) {
    die("❌ Rechnung nicht gefunden");
}

// Positionen laden
$stmt = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id = :id");
$stmt->execute([":id" => $id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Settings laden (Bankverbindung & Zahlungsziel)
$stmt = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('bank_details','payment_terms')");
$settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$bankDetails = $settings['bank_details'] ?? "IBAN: DE12 3456 7890 1234 5678 00 · BIC: GENODEF1XYZ";
$paymentTerms = $settings['payment_terms'] ?? "14 Tage ab Rechnungsdatum ohne Abzüge";

// HTML erzeugen über Twig
$html = $twig->render("invoice_pdf.twig", [
    "invoice" => $invoice,
    "items" => $items,
    "today" => date("d.m.Y"),
    "bankDetails" => $bankDetails,
    "paymentTerms" => $paymentTerms
]);

// PDF generieren mit Dompdf
$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Direkt im Browser ausgeben
$dompdf->stream("Rechnung_" . $invoice['id'] . ".pdf", ["Attachment" => false]);
exit;