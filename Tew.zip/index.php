<?php
declare(strict_types=1);

// Falls später mal ein Login kommt, könnten wir hier prüfen.
// Aktuell leiten wir direkt auf das Dashboard.
header("Location: dashboard.php");
exit;