<?php
declare(strict_types=1);

require_once __DIR__ . "/includes/db.php";

header('Content-Type: application/json; charset=utf-8');

$id = (int)($_GET['id'] ?? 0);

if ($id > 0) {
    $stmt = $pdo->prepare("DELETE FROM appointments WHERE id = :id");
    $stmt->execute([":id" => $id]);

    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['error' => 'Ungültige ID']);