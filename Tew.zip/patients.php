<?php
declare(strict_types=1);

require_once __DIR__ . "/includes/db.php";   // DB Verbindung
require_once __DIR__ . "/includes/twig.php"; // Twig Setup

// Patienten laden (mit Besitzer)
$search = $_GET['search'] ?? '';
if ($search) {
    $stmt = $pdo->prepare("
        SELECT p.*, o.firstname, o.lastname 
        FROM patients p
        JOIN owners o ON p.owner_id = o.id
        WHERE p.name LIKE :s 
           OR o.lastname LIKE :s 
           OR o.firstname LIKE :s
        ORDER BY p.name ASC
    ");
    $stmt->execute([':s' => "%$search%"]);
} else {
    $stmt = $pdo->query("
        SELECT p.*, o.firstname, o.lastname 
        FROM patients p
        JOIN owners o ON p.owner_id = o.id
        ORDER BY p.name ASC
    ");
}

$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Rendern
echo $twig->render("patients.twig", [
    "title"    => "Patientenliste",
    "patients" => $patients,
    "search"   => $search
]);