<?php
declare(strict_types=1);

require_once __DIR__ . "/../vendor/autoload.php";

use Twig\Environment;
use Twig\Loader\FilesystemLoader;

// Template-Pfad setzen
$loader = new FilesystemLoader(__DIR__ . '/../templates');

// Twig-Umgebung konfigurieren
$twig = new Environment($loader, [
    'cache' => false, // oder __DIR__ . '/../cache/twig' für Cache
    'debug' => true,  // Debugging aktivieren
    'autoescape' => 'html'
]);

// Debug-Extension laden (z. B. für dump() im Template)
$twig->addExtension(new \Twig\Extension\DebugExtension());